import{b2 as e}from"./app-rVMg1d2C.js";let r=0;function u(){const n=e(),{name:t="unknown"}=(n==null?void 0:n.type)||{};return`${t}-${++r}`}export{u};
