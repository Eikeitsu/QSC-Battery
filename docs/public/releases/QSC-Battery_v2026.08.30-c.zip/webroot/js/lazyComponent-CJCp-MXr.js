import{A as n,P as o}from"./app-B2DqHOQn.js";function t(e){return n({loader:e,loadingComponent:o,delay:0,timeout:15e3,suspensible:!1})}export{t as l};
